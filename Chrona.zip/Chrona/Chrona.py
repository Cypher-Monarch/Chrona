import os
import pyttsx3
import PyPDF2
import docx
from tkinter import Tk, filedialog, Button, Label
from pydub import AudioSegment

# Initialize the text-to-speech engine
engine = pyttsx3.init()

# Function to read text from a Word file
def read_word_file(file_path):
    doc = docx.Document(file_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

# Function to read text from a PDF file
def read_pdf_file(file_path):
    text = ""
    with open(file_path, "rb") as pdf_file:
        reader = PyPDF2.PdfReader(pdf_file)
        for page in reader.pages:
            text += page.extract_text() + "\n"
    return text

# Function to read text from a TXT file
def read_txt_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
    return text

# Function to set speech properties 
def speak(text, rate=150, volume=1.0):
    engine.setProperty('rate', rate)
    engine.setProperty('volume', volume)
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)
    engine.runAndWait()

# Function to save text as an MP3 file with the same name as the input file
def save_as_mp3(text, input_file_path):
    # Get file name and directory
    file_name = os.path.splitext(os.path.basename(input_file_path))[0]  # Remove extension
    folder_name = os.path.dirname(input_file_path)  # Directory of the input file
    
    # Create the output directory if it doesn't exist
    output_folder = os.path.join(folder_name, "MP3 Converted files")
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Prepare the MP3 file path
    output_file = os.path.join(output_folder, f"{file_name}.mp3")

    # Save the text to a temporary WAV file
    temp_wav = os.path.join(output_folder, "temp.wav")
    engine.save_to_file(text, temp_wav)
    engine.runAndWait()

    # Convert WAV to MP3
    audio = AudioSegment.from_wav(temp_wav)
    audio.export(output_file, format="mp3")
    print(f"✅ MP3 file saved as: {output_file}")

    # Delete the temporary WAV file after conversion
    os.remove(temp_wav)
    print("✅ Temporary WAV file deleted.")

# Function to browse files
def browse_file():
    file_path = filedialog.askopenfilename(filetypes=(("Text files", "*.txt"), ("Word files", "*.docx"), ("PDF files", "*.pdf")))
    if file_path:
        process_file(file_path)

# Function to process the file
def process_file(file_path):
    if file_path.endswith(".docx"):
        text = read_word_file(file_path)
    elif file_path.endswith(".pdf"):
        text = read_pdf_file(file_path)
    elif file_path.endswith(".txt"):
        text = read_txt_file(file_path)
    else:
        label_status.config(text="❌ Unsupported file format!")
        return

    label_status.config(text="✅ File loaded. Processing...")

    # Execute the speech and save as MP3
    speak(text)
    save_as_mp3(text, file_path)
    label_status.config(text="✅ MP3 file saved and speech played!")

# Set up the GUI window
window = Tk()
window.title("Text-to-Speech & MP3 Converter")
window.geometry("400x300")

# Add a label for status updates
label_status = Label(window, text="Choose a file to process", font=("Arial", 14))
label_status.pack(pady=20)

# Add a button to open the file dialog
button_browse = Button(window, text="Browse File", command=browse_file, font=("Arial", 12))
button_browse.pack(pady=10)

# Run the GUI event loop
window.mainloop()
